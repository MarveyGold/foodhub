import { auth } from "#lib/server/auth.ts";
import { svelteKitHandler } from "better-auth/svelte-kit";
import { building } from "$app/env";
import { sequence, type Handle } from "@sveltejs/kit/hooks";

const handleAuth: Handle = async ({ event, resolve }) => {
  return svelteKitHandler({ event, resolve, auth, building });
};

const populateLocals: Handle = async ({ event, resolve }) => {
  // console.log("Headers:", Object.fromEntries(event.request.headers));
  const session = await auth.api.getSession({
    headers: event.request.headers,
  });
  //  console.log("Session:", !!session);
  event.locals.session = session?.session ?? null;
  event.locals.user = session?.user ?? null;
  return resolve(event);
};
export const handle = sequence(handleAuth, populateLocals);
