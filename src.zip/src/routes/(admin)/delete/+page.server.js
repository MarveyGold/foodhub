import { deleteProduct } from "#lib/server/products.js";
import { getProducts } from "#lib/server/products.js";
import { requirePermission } from "#lib/server/permissions.ts";
export async function load() {
  const menu = await getProducts();
  return { menu };
}
export const actions = {
  delete: async ({ request }) => {
    const data = await request.formData();
    const _id = data.get("_id");
    await requirePermission(request.headers, { product: ["delete"] });
    await deleteProduct(_id);
    return { success: true };
  },
};
